import{Q as o}from"./index-DnJ7L95L.js";function t(){const l=o();return e=>l(e.labelKey,{fallback:e.label})}export{t as o};
