import{Q as o}from"./index-nnAvQ19w.js";function t(){const l=o();return e=>l(e.labelKey,{fallback:e.label})}export{t as o};
