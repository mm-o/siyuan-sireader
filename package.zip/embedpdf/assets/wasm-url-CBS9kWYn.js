const e=new URL(""+new URL("embedpdf-WCTppm89.wasm",import.meta.url).href,import.meta.url).href;export{e as default};
