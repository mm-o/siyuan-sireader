import{Q as o}from"./index-B-F9xygG.js";function t(){const l=o();return e=>l(e.labelKey,{fallback:e.label})}export{t as o};
