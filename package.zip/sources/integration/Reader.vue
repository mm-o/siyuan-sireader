<template>
  <div ref="containerRef" class="reader-container" tabindex="0" :style="{'--toolbar-opacity':(1-((currentSettings?.toolbarOpacity??70)/100))*.55}">
    <ReaderSplash v-if="showOpeningSplash" ref="readerSplashRef" :book-info="props.bookInfo" :file-name="props.file?.name" :i18n="i18n" status="opening" />
    <div v-if="loading || error" class="reader-loading"><div v-if="loading" class="spinner"></div><div>{{ error || 'Loading...' }}</div></div>
    <div v-if="showToc&&!loading" class="reader-overlay" @click="closePanels"/>
    <EmbedPdfReader v-if="isEmbedPdfMode" ref="embedPdfReaderRef" :source="embedPdfSource" :book-url="currentBookUrl" :storage-key="props.bookInfo?.dataId || currentBookUrl" :settings="currentSettings" :theme="currentSettings?.theme" :custom-theme="currentSettings?.customTheme" :i18n="i18n" :on-annotation-persisted="syncEmbedPdfEvent" class="viewer-container" @ready="handleEmbedPdfReady" @read-only="setPdfReadOnly" @detached="detachPdfView"/>
    <div v-if="!isEmbedPdfMode&&!loading&&currentSettings?.layoutSettings.showHeader" class="reader-header" :style="{height:`${currentSettings.layoutSettings.marginTopPx||44}px`,paddingLeft:`${(currentSettings.layoutSettings.marginLeftPx||16)+8}px`,paddingRight:`${(currentSettings.layoutSettings.marginRightPx||16)+8}px`}">{{ chapterTitle }}</div>
    <div v-if="!isEmbedPdfMode" ref="viewerContainerRef" class="viewer-container"></div>
    <div v-if="!isEmbedPdfMode&&!loading&&currentSettings?.layoutSettings.showFooter" class="reader-footer" :style="{height:`${currentSettings.layoutSettings.marginBottomPx||44}px`,paddingLeft:`${(currentSettings.layoutSettings.marginLeftPx||16)+8}px`,paddingRight:`${(currentSettings.layoutSettings.marginRightPx||16)+8}px`}">{{ footerInfo }}</div>
    <div v-if="!isEmbedPdfMode&&!loading" class="reader-progress" aria-hidden="true"><span :style="{transform:`scaleX(${readingProgress})`}"/></div>
    <Transition name="toc-popup">
      <div v-if="showToc&&!loading" class="reader-toc-popup" @click.stop>
        <DockShell :active-tab="tocMode" nav-position="top" :tabs="tocTabs" @update:activeTab="tocMode = $event as any">
          <component :is="tocPane" v-bind="tocPaneProps" />
        </DockShell>
      </div>
    </Transition>
    <div v-if="!loading" class="reader-toolbar-group">
      <div v-if="showSearch" class="reader-panel" @click.stop>
        <input v-model="searchQuery" class="search-input" :placeholder="i18n.searchPlaceholder||'Search...'" @keydown.enter="handleSearch" @keydown.esc="showSearch=false" ref="searchInputRef">
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click="handleSearch" :aria-label="i18n.search || 'Search'"><svg><use xlink:href="#iconSearch"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click="handleSearchPrev" :disabled="!hasSearchResults" :aria-label="i18n.previousResult || 'Previous result'"><svg><use xlink:href="#iconUp"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click="handleSearchNext" :disabled="!hasSearchResults" :aria-label="i18n.nextResult || 'Next result'"><svg><use xlink:href="#iconDown"/></svg></button>
        <span class="search-count">{{ searchCount }}</span>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click="handleSearchClear" :aria-label="i18n.clear || 'Clear'"><svg><use xlink:href="#iconClose"/></svg></button>
      </div>
      <div v-if="showQuickMark" class="reader-panel" @click.stop>
        <div class="mark-colors">
          <button v-for="(c,i) in COLORS" :key="c.color" class="mark-color-btn" :class="{active:quickMarkColor===i}" :style="{background:c.bg}" @click="quickMarkColor=i"/>
        </div>
        <span class="panel-divider"/>
        <div class="mark-styles">
          <button v-for="s in STYLES.filter(s=>!s.epubOnly)" :key="s.type" class="mark-style-btn" :class="{active:quickMarkStyle===s.type}" @click="quickMarkStyle=s.type">
            <span :data-type="s.type">{{s.text}}</span>
          </button>
        </div>
      </div>
      <div v-if="!isEmbedPdfMode" class="reader-toolbar" :class="{'is-visible':toolbarVisible}">
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click.stop="handlePrev" :aria-label="i18n.prevChapter||'Previous chapter'"><svg><use xlink:href="#iconLeft"/></svg></button>
        <input v-model="progressJump" class="reader-progress-jump" type="number" min="0" max="100" step="1" placeholder="%" :aria-label="i18n.jumpToProgress || 'Jump to reading progress'" @focus="progressJump=String(Math.round(readingProgress*100))" @keydown.enter.prevent="submitProgressJump">
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click.stop="handleNext" :aria-label="i18n.nextChapter||'Next chapter'"><svg><use xlink:href="#iconRight"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click.stop="openToc" :aria-label="i18n.toc||'Table of contents'"><svg><use xlink:href="#iconList"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click.stop="openQuickNotes" :aria-label="i18n.quickNotes||'Notebook'"><svg><use xlink:href="#lucide-notebook-pen"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" :class="{active:hasBookmark}" @click.stop="toggleBookmark" :aria-label="hasBookmark?(i18n.removeBookmark||'Remove bookmark'):(i18n.addBookmark||'Add bookmark')"><svg><use xlink:href="#iconBookmark"/></svg></button>
        <button class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" :class="{active:showSearch}" @click.stop="toggleSearch" :aria-label="i18n.search||'Search'"><svg><use xlink:href="#iconSearch"/></svg></button>
        <button class="toolbar-btn toolbar-mark-btn ariaLabel" data-position="north" data-tooltip-encoding="none" :class="{active:quickMarkMode}" @click.stop="toggleQuickMark" :aria-label="quickMarkMode ? (i18n.exitQuickMark || 'Exit quick annotation') : (i18n.quickMark || 'Quick annotation')">
          <svg><use xlink:href="#iconMark"/></svg>
          <span class="mark-indicator" :style="{background:COLORS[quickMarkColor].bg}"></span>
        </button>
        <button v-if="ttsEnabled" class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" :class="{active:ttsPlaying}" @click.stop="toggleTTS" :aria-label="ttsPlaying?(i18n.ttsPause||'暂停朗读'):(i18n.ttsPlay||'开始朗读')"><svg><use :xlink:href="ttsPlaying?'#iconPause':'#iconPlay'"/></svg></button>
        <button v-if="isMobile()" class="toolbar-btn ariaLabel" data-position="north" data-tooltip-encoding="none" @click.stop="handleClose" aria-label="Close"><svg><use xlink:href="#iconClose"/></svg></button>
      </div>
    </div>
  </div>
  <MarkPanel v-if="!isEmbedPdfMode" ref="markPanelRef" :root="containerRef" :book-url="getBookUrl()" :manager="markManager" :reader="reader" :current-view="currentView" :read-only="false" :i18n="i18n" :tts-controller="ttsController" :tts-config="currentSettings?.tts" :quick-mark-mode="quickMarkMode" :quick-mark-color="COLORS[quickMarkColor].color" :quick-mark-style="quickMarkStyle" :can="can" :show-upgrade="showUpgrade" @copy="(text,sel)=>handleCopy({text,cfi:sel?.cfi,page:sel?.page,section:sel?.section,rects:sel?.rects,textOffset:sel?.textOffset})" @dict="handleOpenDict" @copy-mark-only="handleCopyToClipboard" />
</template>
<script setup lang="ts">
import { ref, shallowRef, computed, onMounted, onBeforeUnmount } from 'vue'
import { Menu, showMessage } from 'siyuan'
import type { Plugin } from 'siyuan'
import type { ReaderSettings } from '@/composables/useSetting'
import { settingsManager } from '@/composables/useSetting'
import { openDict as openDictDialog } from '@/utils/dictionary'
import { createReader, type FoliateReader } from '@/core/epub/reader'
import { setActiveReader, clearActiveReader } from '@/core/epub/state'
import { COLORS, STYLES, createMarkManager, type MarkManager } from '@/core/MarkManager'
import { saveMobilePosition, isMobile } from '@/utils/mobile'
import EmbedPdfReader from './EmbedPdfReader.vue'
import MarkPanel from './MarkPanel.vue'
import ReaderToc from './ReaderToc.vue'
import ReaderMarks from './ReaderMarks.vue'
import Settings from './Settings.vue'
import ReaderSplash from './ui/ReaderSplash.vue'
import DockShell from './ui/DockShell.vue'
import { gotoEPUB, pdfPageFromCfi } from '@/utils/jump'
import { copyMark as copyMarkUtil } from '@/utils/copy'
import { capturePdfAnnotationImage, isPdfImageAnnotation, openPdf } from '@/utils/embedPdfActions'
import { cloneStorageValue } from '@/core/storage'
import { diagnosticLog } from '@/core/diagnostics'
import { trackPending } from '@/core/storage'
import { isUserEmbedPdfAnnotation } from '@/core/dataMigration'
import { createKeyboardHandler, setupEpubKeyboard, shouldHandleReaderKeydown } from '@/utils/keyboard'
import { getTTSController } from '@/services/TTSPlayer'
import { useLicense } from '@/core/license'
import { upsertEmbedPdfAnnotation } from '@/core/storage'
import { dispatchReaderLifecycle } from '@/integrations/lifecycle'
const props = defineProps<{ file?: File; plugin: Plugin; settings?: ReaderSettings; url?: string; blockId?: string; bookInfo?: any; onReaderReady?: (r: FoliateReader) => void; i18n?: any }>()
const i18n = computed(() => props.i18n || {})
const { can, showUpgrade } = useLicense(i18n.value)
const currentSettings = ref(props.settings)
const getSettings = () => currentSettings.value || props.settings
const openingSplashKey = props.bookInfo?.url || props.url || props.file?.name || ''
const seenOpeningSplash = openingSplashKey ? sessionStorage.getItem(`sireader-opening:${openingSplashKey}`) === '1' : false
const isPdfBook = computed(() => props.file?.name.endsWith('.pdf') || props.url?.split('?')[0].endsWith('.pdf') || props.bookInfo?.format === 'pdf')
const showOpeningSplash = computed(() => {
  if (props.bookInfo?.temporary) return false
  if (isPdfBook.value || !currentSettings.value?.epubOpeningSplash) return false
  return !seenOpeningSplash && (!!props.file || !(props.bookInfo?.progress > 0 || props.bookInfo?.pos?.cfi || props.bookInfo?.pos?.page || props.bookInfo?.pos?.chapter))
})
const tocTabs = computed(() => [
  { id: 'toc', icon: 'lucide-scroll-text', tip: i18n.value.toc || 'TOC' },
  { id: 'mark', icon: 'lucide-square-pen', tip: i18n.value.annotation || i18n.value.mark || 'Marks' },
  { id: 'settings', icon: 'lucide-settings-2', tip: i18n.value.settings || 'Settings' },
])
const tocPane = computed(() => tocMode.value === 'toc' ? ReaderToc : tocMode.value === 'mark' ? ReaderMarks : Settings)
const readerContext = computed(() => ({
  activeView: currentView.value,
  activeReader: reader,
  bookUrl: isEmbedPdfMode.value ? getPdfBookUrl() : getBookUrl(),
  settings: getSettings(),
  readOnlyMarks: !!currentView.value?.readOnlyMarks,
}))
const tocPaneProps = computed(() => tocMode.value === 'settings'
  ? { modelValue: currentSettings.value!, i18n: i18n.value, onSave: saveReaderSettings, 'onUpdate:modelValue': updateSettingsState }
  : { i18n: i18n.value, context: readerContext.value })
const updateSettingsState=(settings:ReaderSettings)=>{
  currentSettings.value=settings
  ;(window as any).__sireader_settings=settings
}
const saveReaderSettings=async()=>{const settings=currentSettings.value||props.settings;settings&&await settingsManager.save(settings)}
const closePanels=()=>{showToc.value=false}
const hasSettingChanged=(prev:any,next:any,keys:string[])=>keys.some(key=>JSON.stringify(prev?.[key])!==JSON.stringify(next?.[key]))
const getBookName=()=>props.bookInfo?.title||props.file?.name||props.url?.split('/').pop()?.split('?')[0]||'book'
const markPanelRef = ref()
const markManager = ref<MarkManager | null>(null)
const handleSettingsUpdate=async(e:Event)=>{
  const s=(e as CustomEvent).detail
  const prev=currentSettings.value
  updateSettingsState(s)
  syncReadingProgress()
  hasSettingChanged(prev,s,['theme','customTheme','backgroundImage','textSettings','paragraphSettings','layoutSettings','visualSettings','viewMode','pageAnimation'])&&reader?.updateSettings?.(s)
    JSON.stringify(prev?.tts)!==JSON.stringify(s?.tts)&&await syncTTS()
}
const containerRef = ref<HTMLElement>()
const viewerContainerRef = ref<HTMLElement>()
const embedPdfReaderRef = ref<InstanceType<typeof EmbedPdfReader> | null>(null)
const readerSplashRef = ref<{ dismiss: () => void; cleanup: () => void; isVisible: () => boolean } | null>(null)
const loading = ref(true)
const error = ref('')
const readingProgress = ref(0)
const chapterTitle = ref('')
const footerInfo = ref('')
const battery = ref<any>(null)
let footerTimer: number | undefined
const progressJump = ref('')
const hasBookmark = ref(false)
const currentBookUrl = ref('')
let readerFocused = false
let touchStartX=0,touchStartY=0
const touchTargets = new Set<EventTarget>()
const canHandleTouchPaging=()=>false
const resetTouch=()=>{touchStartX=0;touchStartY=0}
const isTouchActionTarget=(target:EventTarget|null)=>target instanceof HTMLElement&&!!target.closest('.reader-toolbar-group,.reader-toc-popup,.mark-menu,.sr-popup-panel,input,textarea,button,select,a,[contenteditable="true"]')
const toggleMobileToolbar=()=>isMobile()&&(mobileToolbarVisible.value=!mobileToolbarVisible.value)
const handleTapZone=(x:number)=>{if(!isMobile()||getSettings()?.viewMode==='scroll')return;const third=(containerRef.value?.clientWidth||window.innerWidth)/3;if(x<third)return handlePrev();if(x>third*2)return handleNext();toggleMobileToolbar()}
const handleTouchStart=(e:TouchEvent)=>{if(canHandleTouchPaging()&&e.touches.length===1){touchStartX=e.touches[0].clientX;touchStartY=e.touches[0].clientY}}
const handleTouchEnd=(e:TouchEvent)=>{if(!canHandleTouchPaging()||!touchStartX)return;const{clientX:x,clientY:y}=e.changedTouches[0],dx=x-touchStartX,dy=y-touchStartY;resetTouch();if(isTouchActionTarget(e.target))return;if(Math.abs(dx)>=50&&Math.abs(dx)>Math.abs(dy))return dx>0?handlePrev():handleNext();if(Math.abs(dx)<=30&&Math.abs(dy)<=30)handleTapZone(x)}
const touchPagingEvents:[string,EventListener,AddEventListenerOptions?][]=[['touchstart',handleTouchStart as EventListener,{capture:true,passive:true}],['touchend',handleTouchEnd as EventListener,{capture:true,passive:true}]]
const bindTouchPaging=(target:EventTarget|null|undefined)=>{if(!isMobile()||!target||touchTargets.has(target))return;touchTargets.add(target);touchPagingEvents.forEach(([type,handler,options])=>target.addEventListener(type,handler,options))}
const unbindTouchPaging=()=>{touchTargets.forEach(target=>touchPagingEvents.forEach(([type,handler])=>target.removeEventListener(type,handler,true)));touchTargets.clear()}
const embedPdfSource = ref<File | string | null>(null)
const embedPdfDocumentContext = ref<{ documentId: string; bookUrl: string; storageKey: string } | null>(null)
const embedPdfPages = shallowRef<any>(null)
const embedPdfMarks = ref<any[]>([])
const currentView = ref<any>(null)
let cleanupEmbedPdfEvents: (()=>void) | null = null
const showSearch = ref(false)
const showToc = ref(false)
const showQuickMark = ref(false)
const mobileToolbarVisible = ref(false)
const toolbarVisible = computed(() => mobileToolbarVisible.value || showSearch.value || showToc.value || showQuickMark.value)
const quickMarkMode = ref(false)
const quickMarkColor = ref(0)
const quickMarkStyle = ref<'highlight'|'underline'|'outline'|'dotted'|'dashed'|'double'|'squiggly'>('highlight')
const tocMode = ref<'toc' | 'mark' | 'settings'>('toc')
const searchQuery = ref('')
const searchResults = ref<any[]>([])
const searchCurrentIndex = ref(0)
let reader: FoliateReader | null = null
const ttsController = getTTSController()
const ttsEnabled = computed(() => currentSettings.value?.tts?.enabled || false)
const ttsPlaying = computed(() => ttsController.isActive.value && !ttsController.paused.value)
const clearReadingSelection=()=>{try{reader?.getView?.()?.renderer?.getContents?.()?.forEach(({doc}:any)=>doc.defaultView?.getSelection()?.removeAllRanges());document.getSelection()?.removeAllRanges()}catch{}}
const syncReadingProgress=(detail?:any)=>{const location=detail||(reader as any)?.getProgress?.()||currentView.value?.lastLocation||reader?.getLocation?.();const f=location?.fraction??0;readingProgress.value=Number.isFinite(f)?Math.max(0,Math.min(1,f)):0;chapterTitle.value=location?.tocItem?.label||location?.tocItem?.title||props.bookInfo?.title||getBookName();const layout=currentSettings.value?.layoutSettings;const renderer=reader?.getView?.()?.renderer as any;const page=Number(renderer?.page);const pages=Number(renderer?.pages);const progress=layout?.showProgressInfo&&Number.isFinite(page)&&Number.isFinite(pages)&&pages>0?(layout.progressStyle==='percentage'?`${Math.round(((page+1)/pages)*100)}%`:layout.progressStyle==='reference'&&layout.referencePageCount>0?`${Math.max(1,Math.round(f*layout.referencePageCount))}/${layout.referencePageCount}`:`${Math.min(pages,Math.max(1,page+1))}/${pages}`):'';const minutes=Number(location?.time?.section);const remaining=layout?.showRemainingTime&&Number.isFinite(minutes)&&minutes>0?(i18n.value.chapterRemaining||'Chapter remaining: {minutes} min').replace(/\{minutes\}/g,String(Math.max(1,Math.round(minutes)))):'';const clock=layout?.showCurrentTime?new Date().toLocaleTimeString([], { hour:'2-digit', minute:'2-digit', hour12:layout.use24HourClock?false:undefined }):'';const level=Number(battery.value?.level);const batteryInfo=layout?.showCurrentBatteryStatus&&Number.isFinite(level)?`${i18n.value.batteryStatus||'Battery'} ${Math.round(Math.max(0,Math.min(1,level))*100)}%`:'';footerInfo.value=[remaining,clock,batteryInfo,progress].filter(Boolean).join(' · ')}
const submitProgressJump=async()=>{
  const value=Number(progressJump.value)
  if(!Number.isFinite(value))return
  const fraction=Math.max(0,Math.min(100,value))/100
  progressJump.value=String(Math.round(fraction*100))
  try{await reader?.goToFraction(fraction)}catch{showMessage(i18n.value.jumpFailed || 'Jump failed',1500,'error')}
}
const toggleTTS = () => {if (!can.value('tts')) return showUpgrade(i18n.value.ttsReading || 'Read aloud'); clearReadingSelection(); ttsController.toggle(() => reader, currentSettings.value?.tts, undefined, getBookName())}
const syncTTS = async () => ttsController.sync(currentSettings.value?.tts?.enabled || false)
const marks=computed(()=>markManager.value)
const isEmbedPdfMode=computed(()=>currentView.value?.engine==='embedpdf')
const hasSearchResults=computed(()=>searchResults.value.length>0)
const searchCount=computed(()=>searchResults.value.length?`${searchResults.value.length}`:'0')
const browserSource=(path='')=>path.startsWith('/data/public/')?path.replace('/data/public/','/public/'):path.startsWith('/public/')||path.startsWith('/assets/')||/^https?:\/\//.test(path)?path:path.startsWith('public/')||path.startsWith('assets/')?`/${path}`:''
const PDF_MARKUP_TYPES:Record<string,number>={highlight:9,underline:10,squiggly:11,strikeout:12}
const PDF_REDACT_TYPE=28
const embedPdfColor=(color?:string|null)=>(COLORS.find(item=>item.color===color)?.bg||color||'').toLowerCase()
const embedPdfStyle=(type:number,custom?:any)=>type===PDF_REDACT_TYPE?'redaction':custom?.style||Object.entries(PDF_MARKUP_TYPES).find(([,value])=>value===type)?.[0]||'highlight'
const embedPdfMark=(item:any)=>{
  const a=item?.annotation||item, page=(a.pageIndex??0)+1, bookmark=a.custom?.type==='bookmark', redaction=a.type===PDF_REDACT_TYPE
  const text=a.custom?.title||a.custom?.text||a.contents||(redaction?i18n.value.redaction||'Redaction':i18n.value.annotation||i18n.value.mark||'Annotation')
  const color=[a.strokeColor,a.color,a.fontColor,a.backgroundColor].map(embedPdfColor).find(c=>c&&c!=='transparent')||'#ffcd45'
  return Object.assign(item,{id:a.id,type:bookmark?'bookmark':redaction?'redaction':a.type===1||a.type===3?'note':'highlight',format:'pdf',readOnly:a.flags?.includes('readOnly'),page,cfi:`#page-${page}`,title:bookmark?text:a.custom?.title,text:bookmark?text:a.custom?.text||a.contents||text,note:bookmark||redaction?'':a.custom?.note||a.contents||'',tags:a.custom?.tags||[],blockId:a.custom?.blockId,blockIds:a.custom?.blockIds,color,style:embedPdfStyle(a.type,a.custom),timestamp:new Date(a.created||a.modified||Date.now()).getTime(),chapter:bookmark?'':a.custom?.chapter||`${i18n.value.page||'Page '}${page}${i18n.value.pageSuffix||''}`,customOrder:a.custom?.customOrder})
}
const compact=(value:Record<string,any>)=>Object.fromEntries(Object.entries(value).filter(([,v])=>v!==undefined))
const refreshEmbedPdfMarks=()=>{
  if(isEmbedPdfMode.value)embedPdfMarks.value=(embedPdfReaderRef.value?.annotationActions.list() || []).filter(isUserEmbedPdfAnnotation).map((annotation:any)=>embedPdfMark({annotation}))
}
const latestPdfAnnotation=(item:any)=>embedPdfReaderRef.value?.annotationActions.get(item.id)||item.annotation||item
const imageEmbedPdfMark = async (item: any, contextKey?: string) => {
  if (item.image || (contextKey && embedPdfDocumentContext.value?.storageKey !== contextKey)) return item
  const annotation = latestPdfAnnotation(item)
  if (!isPdfImageAnnotation(annotation)) return item
  return { ...item, annotation, image: await capturePdfAnnotationImage(currentView.value?.render, annotation) }
}
const pdfSyncQueues=new Map<string,Promise<void>>()
const syncEmbedPdfEvent=(event:any)=>{
  const a=event?.annotation,mark=a&&embedPdfMark({annotation:cloneStorageValue(a)})
  const eventUrl=event?.bookUrl||getPdfBookUrl(),eventKey=event?.storageKey||embedPdfDocumentContext.value?.storageKey||props.bookInfo?.dataId||getBookUrl()
  if(!mark)return
  const key=`${eventUrl}:${mark.id}`,previous=pdfSyncQueues.get(key)||Promise.resolve()
  const task=previous.catch(()=>undefined).then(async()=>{
    try{
      const m=await import('@/utils/copy'),ctx={bookUrl:eventUrl,isPdf:true,marks:currentView.value?.marks}
      const next=event?.type==='delete'?mark:await imageEmbedPdfMark(mark,eventKey)
      if(event?.type==='delete')await m.syncMarkOnDelete(next)
      else{
        const durableMarks={updateMark:async(item:any,updates:any)=>{
          const annotation=item.annotation||a
          Object.assign(item,updates)
          const live=latestPdfAnnotation(item), scope=embedPdfReaderRef.value?.annotationActions
          if(embedPdfDocumentContext.value?.storageKey===eventKey&&scope&&live){
            await scope.update(live.id,{custom:updates})
          } else await upsertEmbedPdfAnnotation(eventKey,{annotation:{...annotation,custom:{...(annotation.custom||{}),...updates}}})
        }}
        const durableCtx={...ctx,marks:durableMarks}
        if(event?.type==='update'&&next.blockId)await m.updateMarkInDoc(next,durableCtx)
        else await m.syncMarkOnCreate(next,durableCtx)
      }
    }catch(e){console.error('[PdfSync]',e)}
  })
  pdfSyncQueues.set(key,task)
  void trackPending(task.finally(()=>{if(pdfSyncQueues.get(key)===task)pdfSyncQueues.delete(key)}))
}
const updateEmbedPdfMark=async(item:any,updates:any)=>{
  const requested=item.annotation||item
  const current=latestPdfAnnotation(requested)
  const a={...current,custom:{...(current.custom||{})}}
  a.custom={...a.custom,...compact({text:updates.text,title:updates.title,note:updates.note,tags:updates.tags,style:updates.style,blockId:updates.blockId,blockIds:updates.blockIds})}
  a.contents=updates.note??updates.text??a.contents
  if(updates.style)a.type=PDF_MARKUP_TYPES[updates.style]||a.type
  if(updates.color)a.strokeColor=a.color=updates.color
  Object.assign(item,updates,{style:embedPdfStyle(a.type,a.custom),color:embedPdfColor(a.strokeColor||a.color||'')})
  await embedPdfReaderRef.value?.annotationActions.update(a.id,compact({type:a.type,contents:a.contents,custom:a.custom,strokeColor:a.strokeColor,color:a.color}))
  await embedPdfReaderRef.value?.flushAnnotations?.()
}
const deleteEmbedPdfMark=async(item:any)=>{const a=item.annotation||item;await embedPdfReaderRef.value?.annotationActions.delete(a.id);await embedPdfReaderRef.value?.flushAnnotations?.();return true}
const toggleEmbedPdfBookmark=async(loc:any,title?:string)=>{
  const page=typeof loc==='string'?pdfPageFromCfi(loc):Number(loc||0), found=embedPdfMarks.value.find(item=>item.type==='bookmark'&&item.page===page)
  if(!page)return false
  if(found)return await deleteEmbedPdfMark(found),false
  const text=title||`${i18n.value.page || 'Page'} ${page}${i18n.value.pageSuffix || ''}`, now=new Date()
  await embedPdfReaderRef.value?.annotationActions.create({id:`bookmark-${Date.now()}`,type:1,pageIndex:page-1,rect:{origin:{x:0,y:0},size:{width:1,height:1}},contents:text,created:now,modified:now,flags:['hidden','noView'],custom:{type:'bookmark',title:text}})
  await embedPdfReaderRef.value?.flushAnnotations?.()
  return true
}
const initEmbedPdfMode=async(loadSource:()=>Promise<File|string|null>)=>{
  const file=await loadSource()
  if(!file)throw new Error(i18n.value.pdfFileMissing || 'PDF file is missing')
  embedPdfDocumentContext.value=null
  embedPdfSource.value=file
  embedPdfMarks.value=[]
  markManager.value=null
  currentView.value = {
    engine: 'embedpdf',
    isPdf: true,
    marks: {
      getAnnotations: () => embedPdfMarks.value.filter(item => item.type !== 'bookmark'),
      getBookmarks: () => embedPdfMarks.value.filter(item => item.type === 'bookmark'),
      updateMark: updateEmbedPdfMark,
      deleteMark: deleteEmbedPdfMark,
      toggleBookmark: toggleEmbedPdfBookmark,
      imageMark: imageEmbedPdfMark,
    },
    goTo: (page: number, id?: string) => {
      embedPdfPages.value?.goToPage((Number(page) || 1) - 1)
      if (id) embedPdfReaderRef.value?.annotationActions.select(id)
    },
    getCurrentPage: () => (embedPdfPages.value?.getCurrentPageIndex() ?? 0) + 1,
    cleanup: () => {
      cleanupEmbedPdfEvents?.()
      cleanupEmbedPdfEvents = null
      embedPdfSource.value = null
      embedPdfPages.value = null
      embedPdfMarks.value = []
    },
  }
  setActiveReader(currentView.value,null,getSettings(),getBookUrl())
}
const setPdfReadOnly=(value:boolean)=>{if(currentView.value)currentView.value.readOnlyMarks=value}
const detachPdfView=()=>{
  cleanupEmbedPdfEvents?.()
  cleanupEmbedPdfEvents=null
  embedPdfDocumentContext.value=null
  embedPdfPages.value=null
  embedPdfMarks.value=[]
}
const handleEmbedPdfReady=(viewer:any,context:{documentId:string;bookUrl:string;storageKey:string})=>{
  embedPdfDocumentContext.value=context
  const scope=viewer.forDocument(context.documentId)
  const stage=scope.get('stage')
  embedPdfPages.value=stage
  currentView.value.render=scope.get('render')
  const emitPage=()=>window.dispatchEvent(new CustomEvent('sireader:pdf-page',{detail:{bookUrl:getBookUrl(),page:stage.getCurrentPageIndex()+1}}))
  cleanupEmbedPdfEvents?.()
  cleanupEmbedPdfEvents=stage.onPageChanged(emitPage)
  emitPage()
  let textDocument: ReturnType<typeof openPdf> | undefined
  const pageText=new Map<number,Promise<string>>()
  currentView.value.getPageText=(page:number)=>{
    if (!pageText.has(page)) pageText.set(page,(async()=>{
      textDocument ||= viewer.documents.download(context.documentId).then(openPdf)
      const document=await textDocument
      const {pages}=await document.pages.list()
      return pages[page-1] ? (await document.page(pages[page-1].ref).text.get()).text : ''
    })().catch(error=>{pageText.delete(page);throw error}))
    return pageText.get(page)
  }
  const offPage=cleanupEmbedPdfEvents
  cleanupEmbedPdfEvents=()=>{
    offPage?.()
    void textDocument?.then(document=>document.close()).catch(()=>{})
  }
  const outline=scope.get('outline')
  currentView.value.activateOutline=(id:number)=>{
    const ref={kind:'objectNumber',objectNumber:id}
    return !!outline.get(ref) && outline.activate(ref).status!=='none'
  }
  currentView.value.getPdfToc=async()=>{
    await outline.ensureLoaded()
    const branch=(parent:any):any[]=>outline.getChildren(parent).map((item:any)=>{
      const page=item.target?.kind==='goto' ? viewer.documents.getPageIndex(item.target.destination.page,context.documentId) : -1
      return { id:item.ref.objectNumber,label:item.title,href:page>=0?`#page-${page+1}`:'',subitems:branch(item.ref) }
    })
    return branch(null)
  }
  currentView.value.executePdfCommand=(id:string)=>{
    if (!id || !isThisActiveReader()) return
    void embedPdfReaderRef.value?.executeCommand(id)?.catch(error=>showMessage(error?.message || i18n.value.pdfOperationFailed || 'PDF operation failed',2000,'error'))
  }
  refreshEmbedPdfMarks()
  window.dispatchEvent(new CustomEvent('sireader:tab-switched'))
}
const loadViewer=()=>document.getElementById('protyleViewerScript')?Promise.resolve():new Promise<void>((resolve,reject)=>{
  const s=document.createElement('script')
  s.id='protyleViewerScript';s.src='/stage/protyle/js/viewerjs/viewer.js?v=1.11.8';s.onload=()=>resolve();s.onerror=()=>reject(new Error('viewer.js load failed'));document.head.appendChild(s)
})
let activeMediaMenu:any=null
const closeMediaMenu=()=>{activeMediaMenu?.element?.remove?.();activeMediaMenu=null}
const notifyHostClick=()=>document.body?.dispatchEvent(new MouseEvent('click',{bubbles:true,view:window}))
const openMediaMenu=(x:number,y:number,setup:(m:Menu)=>void)=>{closeMediaMenu();const m=new Menu('sireader-media-menu',()=>activeMediaMenu=null);setup(m);activeMediaMenu=m;m.open({x,y})}
const openImageMenu = ({ item, x, y }: any) => openMediaMenu(x, y, m => {
  m.addItem({ icon: 'iconCopy', label: i18n.value.copyImage || 'Copy Image', click: () => handleCopyToClipboard(item) })
  m.addItem({ icon: 'iconUpload', label: i18n.value.exportImage || 'Export Image', click: () => handleCopy(item) })
  m.addItem({ icon: 'iconMark', label: i18n.value.markImage || 'Annotate Image', click: async () => markPanelRef.value?.showCard(await (markManager.value as any)?.addImageMark(item.image, item.text, item.cfi), x, y, true) })
})
const copyImageAsPng=async(src:string)=>{
  try{
    const image=new Image()
    image.src=src
    await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject})
    const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight
    canvas.getContext('2d')?.drawImage(image,0,0)
    const blob=await new Promise<Blob|null>(resolve=>canvas.toBlob(resolve,'image/png'))
    if(blob) await navigator.clipboard.write([new ClipboardItem({'image/png':blob})])
  }catch{showMessage(i18n.value.copyImageFailed || 'Copy image failed',2000,'error')}
}
const openImageViewer=async({item}:any)=>{
  if(!item?.image)return
  await loadViewer().catch(()=>{})
  if(!(window as any).Viewer)return window.open(item.image,'_blank')
  const root=document.createElement('ul')
  const mediaSrc=(el:any,doc:any)=>{if(el.localName==='img')return el.currentSrc||el.src;const image=el.querySelector?.('image');const href=image?.getAttribute('href')||image?.getAttributeNS?.('http://www.w3.org/1999/xlink','href');return href&&(/^data:|^blob:|^[a-z]+:/i.test(href)?href:new URL(href,doc.baseURI).href)}
  const images=[...new Set([...(reader?.getView?.()?.renderer?.getContents?.()?.flatMap(({doc}:any)=>Array.from(doc.querySelectorAll('img, svg')).map((el:any)=>mediaSrc(el,doc)))||[]),item.image].filter(Boolean))]
  images.forEach((src:any)=>{const li=document.createElement('li');li.innerHTML=`<img src="${encodeURI(src)}">`;root.appendChild(li)})
  let initialViewIndex=-1
  images.some((src:any,index)=>{if(item.image.endsWith(encodeURI(src))||item.image.endsWith(src)){initialViewIndex=index;return true}return false})
  let cleaned=false
  const close=()=>{viewer.destroy();if(!cleaned)cleaned=true}
  const viewer=(window as any).siyuan.viewer=new (window as any).Viewer(root,{initialViewIndex:item.image?initialViewIndex:0,title:[1,(image:HTMLImageElement,data:any)=>{let name=image.alt||image.src.substring(image.src.lastIndexOf('/')+1);name=name.substring(0,name.lastIndexOf('.')).replace(/-\d{14}-\w{7}$/,'');return `${name} [${data.naturalWidth} × ${data.naturalHeight}]`}],button:false,transition:false,ready:()=>{const languages=(window as any).siyuan.languages||{};const labels:any={'zoom-in':languages.zoomIn||'Zoom in','zoom-out':languages.zoomOut||'Zoom out','one-to-one':languages.pageScaleActual||'Actual size',reset:languages.reset||'Reset',prev:languages.previous||'Previous image',play:languages.imageViewerPlay||'Play',next:languages.next||'Next image','rotate-left':languages.rotateCcw||'Rotate counter-clockwise','rotate-right':languages.rotateCw||'Rotate clockwise','flip-horizontal':languages.imageFlipHorizontal||'Flip horizontally','flip-vertical':languages.imageFlipVertical||'Flip vertically',copy:languages.copyAsPNG||'Copy as PNG','copy-file':languages.copyFile||'Copy file',close:languages.close||'Close'};const copy=viewer.toolbar.querySelector('.viewer-copy');if(copy)copy.innerHTML='<svg><use xlink:href="#iconImage"></use></svg>';const copyFile=viewer.toolbar.querySelector('.viewer-copy-file');if(copyFile){copyFile.innerHTML='<svg><use xlink:href="#iconFile"></use></svg>';copyFile.classList.add('fn__none')}Object.entries(labels).forEach(([action,label])=>{const button=viewer.toolbar.querySelector(`.viewer-${action}`);button?.classList.add('ariaLabel');button?.setAttribute('aria-label',label as string);button?.setAttribute('data-position','north')})},hidden:close,view:()=>viewer.toolbar.querySelector('.viewer-copy-file')?.classList.add('fn__none'),viewed:()=>viewer.toolbar.querySelector('.viewer-copy-file')?.classList.add('fn__none'),toolbar:{zoomIn:true,zoomOut:true,oneToOne:true,reset:true,prev:true,play:true,next:true,rotateLeft:true,rotateRight:true,flipHorizontal:true,flipVertical:true,copy:()=>viewer.viewed&&viewer.image&&copyImageAsPng(viewer.image.src),copyFile:()=>{},close}})
  viewer.show()
}
const openTableMenu = ({ item, x, y }: any) => openMediaMenu(x, y, m => {
  m.addItem({ icon: 'iconCopy', label: i18n.value.copyTable || 'Copy Table', click: () => navigator.clipboard.writeText(item.html || item.text || '') })
  m.addItem({ icon: 'iconRef', label: i18n.value.locateTable || 'Locate Table', click: () => item.cfi && reader?.goTo(item.cfi) })
})
const init=async()=>{
  if(!containerRef.value)return
  try{
    loading.value=true
    error.value=''
    currentSettings.value = await settingsManager.get().catch(() => currentSettings.value || props.settings)
    const bookUrl=props.bookInfo?.url||props.url||(props.file?`file://${props.file.name}`:`book-${Date.now()}`)
    currentBookUrl.value=bookUrl
    ;(window as any).__currentBookUrl=bookUrl
    ;(window as any).__sireader_bookInfo=props.bookInfo || { url: bookUrl, title: getBookName() }
    const isPdf=isPdfBook.value
    const isTemporary=!!props.bookInfo?.temporary
    const{bookshelfManager}=await import('@/core/bookshelf')
    const onProgress=async(detail?:any)=>{syncReadingProgress(detail);updateBookmarkState();!isTemporary&&await bookshelfManager.updateProgressAuto(bookUrl,reader,currentView.value)}
    const loadSource=async()=>{
      if(props.file)return props.file
      if(props.url)return props.url
      const path=props.bookInfo?.path
      if(!path)return null
      const direct=isPdf?browserSource(path):''
      if(direct)return direct
      return bookshelfManager.loadFile(path)
    }
    if(isPdf){
      await initEmbedPdfMode(loadSource)
    }else{
      reader=await createReader({container:viewerContainerRef.value!,settings:getSettings()!,plugin:props.plugin})
      await reader.open(async()=>await loadSource()||await Promise.reject(new Error(i18n.value.bookMissing || 'No book provided')),props.bookInfo?.format)
      const view=reader.getView()
      markManager.value=createMarkManager({format:'epub',view,plugin:props.plugin,bookUrl,bookName:getBookName(),reader})
      !isTemporary&&await markManager.value.init()
      ;(view as any).marks=markManager.value
      reader.on('image-open', openImageViewer)
      reader.on('image-menu', openImageMenu)
      reader.on('table-menu', openTableMenu)
      reader.on('table-open', openTableMenu)
      reader.on('content-interaction', () => { closeMediaMenu(); notifyHostClick() })
      !isTemporary&&bookshelfManager.restoreProgress(bookUrl,reader).catch(()=>{})
      reader.on('relocate',onProgress)
      setupEpubKeyboard(
        reader,
        handleKeydown,
        (doc,e)=>markPanelRef.value?.checkSelection(doc,e),
        x=>handleTapZone(x),
        distance=>isEpubScrollMode()?reader?.prev(distance):reader?.goLeft(),
        distance=>isEpubScrollMode()?reader?.next(distance):reader?.goRight()
      )
      currentView.value=view
      syncReadingProgress()
      setActiveReader(view,reader,getSettings(),getBookUrl())
      props.onReaderReady?.(reader)
    }
    await syncTTS()
    markPanelRef.value?.setupAnnotationListeners()
    if (!isTemporary && openingSplashKey) sessionStorage.setItem(`sireader-opening:${openingSplashKey}`, '1')
  }catch(e){
    error.value=e instanceof Error?e.message:(i18n.value.loadError || 'Failed to load')
    markPanelRef.value?.closeAll()
  }finally{
    loading.value=false
    setTimeout(()=>readerSplashRef.value?.dismiss(),300)
  }
}
const copyReaderMark=(item:any,clipboard=false)=>{
  if(typeof item==='string'||(!item.id&&item.text&&!item.image)){const loc=reader?.getLocation();item={text:item.text||item,cfi:item.cfi,page:item.page,chapter:loc?.tocItem?.label||loc?.tocItem?.title,id:''}}
  copyMarkUtil(item,{bookUrl:isEmbedPdfMode.value?getPdfBookUrl():getBookUrl(),bookInfo:props.bookInfo,settings:clipboard?{...(getSettings()||{}),noteInsertTarget:'clipboard'}:getSettings(),reader,showMsg:(msg:string)=>showMessage(msg,1000)})
}
const handleCopy=(item:any)=>copyReaderMark(item)
const handleCopyToClipboard=(item:any)=>copyReaderMark(item,true)
const handleOpenDict=(text:string,x:number,y:number,selection:any)=>selection&&openDictDialog(text,x,y,selection)
const isEpubScrollMode=()=>getSettings()?.viewMode==='scroll'
const flipPage=async(dir:'prev'|'next',distance?:number)=>{
  if(dir==='next'&&readerSplashRef.value?.isVisible())return readerSplashRef.value.dismiss()
  if(props.bookInfo?.temporary&&typeof props.bookInfo?.webpageTurn==='function')return props.bookInfo.webpageTurn(dir)
  if(isEmbedPdfMode.value)return embedPdfPages.value?.[dir==='prev'?'previousPage':'nextPage']()
    if(reader)return isEpubScrollMode() ? reader[dir](distance) : reader[dir==='prev'?'goLeft':'goRight']()
  return currentView.value?.[dir]?.()||currentView.value?.[dir==='prev'?'goLeft':'goRight']?.()
}
const handlePrev=(distance?:number)=>flipPage('prev',distance)
const handleNext=(distance?:number)=>flipPage('next',distance)
const searchInputRef=ref<HTMLInputElement>()
const toggleSearch=()=>{showSearch.value=!showSearch.value;showSearch.value&&(showQuickMark.value=quickMarkMode.value=false,setTimeout(()=>searchInputRef.value?.focus(),100))}
const toggleQuickMark=()=>{if(!can.value('quick-mark'))return showUpgrade(i18n.value.quickMark || 'Quick annotation');showQuickMark.value=!showQuickMark.value;showQuickMark.value&&(showSearch.value=false);quickMarkMode.value=showQuickMark.value}
const syncSearchNav=(r:any)=>{if(r)searchCurrentIndex.value=reader.searchManager.getCurrentIndex()}
const handleSearch=async()=>{
  if(!searchQuery.value.trim())return
  if(reader?.searchManager){
    searchResults.value=[]
    for await(const r of reader.search(searchQuery.value))searchResults.value.push(r)
    searchCurrentIndex.value=searchResults.value.length?0:-1
  }
}
const moveSearch=(dir:'next'|'prev')=>syncSearchNav(reader?.[dir==='next'?'nextSearchResult':'prevSearchResult']())
const handleSearchNext=()=>moveSearch('next')
const handleSearchPrev=()=>moveSearch('prev')
const handleSearchClear=()=>{searchQuery.value='';searchResults.value=[];searchCurrentIndex.value=0;reader?.clearSearch();showSearch.value=false}
const updateBookmarkState=()=>hasBookmark.value=!!markManager.value?.hasBookmark?.()
const toggleBookmark=async()=>{if(isEmbedPdfMode.value)return;try{hasBookmark.value=await marks.value?.toggleBookmark?.();window.dispatchEvent(new CustomEvent('sireader:marks-updated'))}catch(e:any){showMessage(e.message||i18n.value.operationFailed||'Operation failed',2000,'error')}}
const getBookUrl=()=>currentBookUrl.value||props.bookInfo?.url||props.url||''
const getPdfBookUrl=()=>embedPdfDocumentContext.value?.bookUrl||getBookUrl()
const savePosition=()=>isMobile()&&getBookUrl()&&reader&&saveMobilePosition(getBookUrl(),{cfi:reader.getLocation()?.cfi})
const syncReaderFocus=(focused:boolean)=>{const bookUrl=getBookUrl();if(!bookUrl||readerFocused===focused)return;readerFocused=focused;dispatchReaderLifecycle(focused?'focus':'blur',bookUrl)}
const hasReaderFocus=()=>!!containerRef.value&&containerRef.value.contains(document.activeElement)
const handleFocusIn=()=>syncReaderFocus(true)
const handleFocusOut=()=>setTimeout(()=>syncReaderFocus(hasReaderFocus()),0)
const handleWindowBlur=()=>syncReaderFocus(false)
const handleWindowFocus=()=>syncReaderFocus(hasReaderFocus())
const handleVisibilityChange=()=>syncReaderFocus(!document.hidden&&hasReaderFocus())
const openToc=()=>{showToc.value=!showToc.value}
const openQuickNotes=()=>window.dispatchEvent(new Event('sireader:open-quick-notes'))
const handleClose=()=>{savePosition();window.dispatchEvent(new CustomEvent('reader:mobile-close'))}
const isThisActiveReader=()=>!(window as any).__sireader_active_view||(window as any).__sireader_active_view===currentView.value
const activeOnly=<T extends any[]>(fn:(...args:T)=>any)=>(...args:T)=>isThisActiveReader()?fn(...args):undefined
const handleGoto=(e:CustomEvent)=>{
  const{cfi,id,bookUrl}=e.detail
  if(bookUrl&&bookUrl!==currentBookUrl.value)return
  if(!cfi)return
  const pdfPage=pdfPageFromCfi(cfi)
  if(isEmbedPdfMode.value&&pdfPage){
    currentView.value?.goTo?.(pdfPage,id)
    return
  }
  void gotoEPUB(cfi,id,reader,markManager.value)
}
const handleUndo=()=>markManager.value?.undo?.()
const getScrollStep=()=>{
  if(!isEpubScrollMode())return undefined
  const size=Number(reader?.getView?.()?.renderer?.size)
  return Number.isFinite(size)&&size>0?size*.9:undefined
}
const keyboardHandler=createKeyboardHandler({handlePrev,handleNext,handleUndo,getScrollStep})
const handleKeydown=(e:KeyboardEvent)=>shouldHandleReaderKeydown(isEmbedPdfMode.value,isThisActiveReader())&&keyboardHandler(e)
const events=[
  ['tts:start-reader',()=>{if(isEmbedPdfMode.value||!isThisActiveReader()||ttsController.isActive.value)return;toggleTTS()}],
  ['sireaderSettingsUpdated',handleSettingsUpdate],
  ['sireader:goto',handleGoto],
  ['sireader:marks-updated',refreshEmbedPdfMarks],
  ['sireader:close-reader-panels',closePanels],
  ['sireader:togglePdfToc',activeOnly(openToc)],
  ['sireader:toggleBookmark',activeOnly(toggleBookmark)],
  ['sireader:quickNote',async()=>{try{if(isEmbedPdfMode.value||!currentView.value||!containerRef.value?.isConnected||!isThisActiveReader())return;const { openNoteTargetFloat } = await import('@/utils/copy');await openNoteTargetFloat(getBookUrl(),getSettings(),containerRef.value!)}catch(e:any){showMessage(e?.message||'Failed',2000,'error')}}],
  ['sireader:prevPage',activeOnly(handlePrev)],
  ['sireader:nextPage',activeOnly(handleNext)],
  ['sireader:pdf-command',activeOnly((event:CustomEvent)=>{if(isEmbedPdfMode.value)currentView.value?.executePdfCommand?.(event.detail)})],
]as const
const suppressError=(e:PromiseRejectionEvent)=>/createTreeWalker|destroy/.test(e.reason?.message||'')&&e.preventDefault()
const setupTabObserver=()=>{if(isMobile())return;let el=containerRef.value?.parentElement;while(el){if(el.hasAttribute('data-id')){const h=document.querySelector(`li[data-type="tab-header"][data-id="${el.getAttribute('data-id')}"]`);if(h){const obs=new MutationObserver(ms=>ms.forEach(m=>{if(m.type!=='attributes'||m.attributeName!=='class')return;const focused=(m.target as HTMLElement).classList.contains('item--focus');focused&&setActiveReader(currentView.value,reader,getSettings(),getBookUrl());focused&&window.dispatchEvent(new CustomEvent('sireader:tab-switched'));syncReaderFocus(focused&&hasReaderFocus())}));obs.observe(h,{attributes:true,attributeFilter:['class']});(containerRef.value as any).__observer=obs;break}}el=el.parentElement}}
const resize=()=>{
  reader?.resize?.()
}
defineExpose({ resize })
onMounted(()=>{init();if(!isPdfBook.value){footerTimer=window.setInterval(syncReadingProgress,60000);const getBattery=(navigator as any).getBattery;if(typeof getBattery==='function')void getBattery.call(navigator).then((value:any)=>{battery.value=value;syncReadingProgress()}).catch(()=>{})}containerRef.value?.focus();events.forEach(([e,h])=>window.addEventListener(e,h as any));window.addEventListener('keydown',handleKeydown);window.addEventListener('unhandledrejection',suppressError);window.addEventListener('blur',handleWindowBlur);window.addEventListener('focus',handleWindowFocus);document.addEventListener('visibilitychange',handleVisibilityChange);setupTabObserver();const c=containerRef.value;c&&(c.addEventListener('focusin',handleFocusIn),c.addEventListener('focusout',handleFocusOut));bindTouchPaging(c);bindTouchPaging(viewerContainerRef.value);dispatchReaderLifecycle('open',getBookUrl());syncReaderFocus(true)})
onBeforeUnmount(()=>{
  if(footerTimer)window.clearInterval(footerTimer)
  if (isThisActiveReader()) ttsController.destroy()
  void trackPending((async()=>{
  const view=currentView.value,c=containerRef.value
  syncReaderFocus(false);dispatchReaderLifecycle('close',getBookUrl())
  const saving = Promise.resolve(savePosition())
  const closing = reader?.destroy()
  const closingTasks = Promise.allSettled([saving, closing, embedPdfReaderRef.value?.flushAnnotations?.()])
  readerSplashRef.value?.cleanup();clearActiveReader(view);closeMediaMenu()
  events.forEach(([e,h])=>window.removeEventListener(e,h as any));window.removeEventListener('keydown',handleKeydown);window.removeEventListener('unhandledrejection',suppressError);window.removeEventListener('blur',handleWindowBlur);window.removeEventListener('focus',handleWindowFocus);document.removeEventListener('visibilitychange',handleVisibilityChange);(c as any)?.__observer?.disconnect();c&&(c.removeEventListener('focusin',handleFocusIn),c.removeEventListener('focusout',handleFocusOut));unbindTouchPaging()
  for (const result of await closingTasks) if (result.status === 'rejected') diagnosticLog('error', 'reader.close.failed', { error: result.reason })
  try{view?.cleanup?.()}catch{}
  await markManager.value?.destroy()
  const{bookshelfManager}=await import('@/core/bookshelf');await bookshelfManager.cleanup();await bookshelfManager.flush()
  setTimeout(()=>viewerContainerRef.value&&(viewerContainerRef.value.innerHTML=''),50)
})())})
</script>
<style scoped lang="scss">
.reader-container{position:relative;width:100%;height:100%;outline:none;user-select:text;-webkit-user-select:text;isolation:isolate;display:flex;flex-direction:column;background:var(--b3-theme-background)}
.reader-overlay{position:absolute;inset:0;z-index:999;background:transparent}
.viewer-container{flex:1;min-width:0;min-height:0;position:relative;overflow:hidden;background:var(--b3-theme-background)}
.reader-header,.reader-footer{position:absolute;left:0;right:0;z-index:2;display:flex;align-items:center;overflow:hidden;color:var(--b3-theme-on-background);font:12px/1 sans-serif;white-space:nowrap;text-overflow:ellipsis;pointer-events:none;opacity:.65}.reader-header{top:0;justify-content:flex-start}.reader-footer{bottom:0;justify-content:flex-start}
.reader-progress{position:absolute;left:0;right:0;bottom:0;height:2px;z-index:1000;pointer-events:none;background:color-mix(in srgb,var(--b3-theme-primary) 14%,transparent);overflow:hidden;span{display:block;width:100%;height:100%;transform-origin:left center;background:var(--b3-theme-primary);transition:transform .18s ease-out}}
.reader-loading{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:16px;color:var(--b3-theme-on-background);z-index:10;pointer-events:none}
.spinner{width:48px;height:48px;border:4px solid var(--b3-theme-primary-lighter);border-top-color:var(--b3-theme-primary);border-radius:50%;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.reader-toolbar-group{position:absolute;bottom:16px;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:8px;z-index:1001;opacity:var(--toolbar-opacity);transition:opacity .2s;&:hover{opacity:1}}
.reader-toolbar,.reader-panel{display:flex;align-items:center;gap:2px;padding:3px 4px;background:var(--b3-theme-surface);border:1px solid var(--b3-border-color);border-radius:6px;box-shadow:0 2px 8px #0002;transition:opacity .2s}
.toolbar-btn{width:28px;height:28px;display:flex;align-items:center;justify-content:center;border:none;background:transparent;border-radius:4px;cursor:pointer;transition:all .15s;svg{width:14px;height:14px}&:hover{background:var(--b3-list-hover)}&.active{background:var(--b3-theme-primary-lightest);color:var(--b3-theme-primary)}}
.toolbar-mark-btn{position:relative;.mark-indicator{position:absolute;right:2px;bottom:2px;width:8px;height:8px;border-radius:50%;border:1.5px solid var(--b3-theme-surface);box-shadow:0 0 0 .5px var(--b3-border-color)}}
.search-input{width:160px;height:22px;padding:0 6px;border:none;background:var(--b3-theme-background-light);color:var(--b3-theme-on-surface);font-size:11px;border-radius:3px;transition:background .15s;&:focus{outline:none;background:var(--b3-theme-background)}}
.reader-progress-jump{width:24px;height:20px;padding:0 1px;border:0;border-radius:2px;background:var(--b3-theme-background-light);color:var(--b3-theme-on-surface);font-size:9px;text-align:center;outline:none;appearance:textfield}.reader-progress-jump::-webkit-inner-spin-button,.reader-progress-jump::-webkit-outer-spin-button{margin:0;appearance:none}.reader-progress-jump:focus{background:var(--b3-theme-background);box-shadow:inset 0 -1px 0 var(--b3-theme-primary)}
.search-count{font-size:11px;color:var(--b3-theme-on-surface-variant);min-width:40px;text-align:center;opacity:.7}
.panel-divider{width:1px;height:20px;background:var(--b3-border-color)}
.mark-colors,.mark-styles{display:flex;gap:3px}
.mark-color-btn{width:24px;height:24px;border:2px solid transparent;border-radius:50%;cursor:pointer;transition:all .15s;padding:0;&.active{border-color:var(--b3-theme-on-surface);transform:scale(1.1)}&:hover{transform:scale(1.05)}}
.mark-style-btn{width:28px;height:24px;display:flex;align-items:center;justify-content:center;border:1px solid var(--b3-border-color);background:transparent;border-radius:4px;cursor:pointer;transition:all .15s;color:var(--b3-theme-on-surface);font-size:12px;font-weight:600;&.active{background:var(--b3-theme-primary-lightest);border-color:var(--b3-theme-primary);color:var(--b3-theme-primary)}&:hover{background:var(--b3-list-hover)}span[data-type="underline"]{text-decoration:underline}span[data-type="outline"]{border:1px solid currentColor;padding:0 2px}span[data-type="dotted"]{border-bottom:2px dotted currentColor}span[data-type="dashed"]{border-bottom:2px dashed currentColor}span[data-type="double"]{border-bottom:3px double currentColor}span[data-type="squiggly"]{text-decoration:underline wavy}}
.reader-toc-popup{position:absolute;bottom:60px;left:50%;transform:translateX(-50%);width:min(420px,92vw);height:min(520px,72vh);background:var(--b3-theme-surface);border:1px solid var(--b3-border-color);border-radius:8px;box-shadow:0 4px 20px #0003;z-index:1002;overflow:hidden}
.toc-popup-enter-active,.toc-popup-leave-active{transition:all .2s}
.toc-popup-enter-from,.toc-popup-leave-to{opacity:0;transform:translate(-50%,10px)}
</style>
